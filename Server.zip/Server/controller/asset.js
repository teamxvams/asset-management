const Asset = require('../model/asset')
const AssetPeripherals = require('../model/asset_peripherals')
const { Op } = require('sequelize')

module.exports = {
    addAsset: (req, res) => {
        const { asset_id, asset_details, model_no, serial_no, grcir_no, grcir_date,po_no,po_date, price,
            warrenty, vender, remark, peripherals, category_id, subcategory_id,
            asset_group_id, division_id,department_id,project_id, indent_no, indent_date,group, employee_id,
            acquired_date, issue_date, record } = req.body
        let assetId = 0
        Asset.findAndCountAll({
            attributes: ["asset_id"],
            where: { asset_id: { [Op.like]: asset_id + "%" } }
        }).then(result => {
            let tempid = result.count + 1;
            for (let index = 0; index < record; index++) {
                assetId = asset_id + "-" + tempid;
                let asset = {
                    category_id: category_id,
                    subcategory_id: subcategory_id,
                    asset_group_id: asset_group_id,
                    division_id: division_id,
                    department_id: department_id,
                    project_id: project_id,
                    employee_id: employee_id,
                    acquired_date: acquired_date,
                    issue_date: issue_date,
                    indent_id: indent_no,
                    indent_date: indent_date,
                    group: group,
                    asset_id: assetId,
                    asset_details: asset_details,
                    model_no: model_no,
                    serial_no: serial_no,
                    grcir_no: grcir_no,
                    grcir_date: grcir_date,
                    po_no: po_no,
                    po_date: po_date,
                    price: price,
                    warrenty: warrenty,
                    vender: vender,
                    remark: remark
                }
                console.log(asset)
                Asset.create(asset).then(row => {
                    let len = peripherals.length;
                    if (len) {
                        for (let i = 0; i < len; i++) {
                            let per = {
                                asset_id: row.id,
                                peripherals_id: peripherals[i].peripherals_id,
                                serial_no: peripherals[i].serial_no
                            }
                            AssetPeripherals.create(per);
                        }
                    }
                    res.status(200).json({ result: row })
                }).catch(err => {
                    res.status(500).json({ result: err })
                })
                tempid++;
            }

        }).catch(err => {
            res.status(500).json({ result: err })
        })
    },

    getAllAsset: (req, res) => {
        Asset.findAll()
            .then(result => {
                res.status(200).json({ result: result })
            })
            .catch(err => {
                res.status(500).json({ result: err })
            })
    },

    updateAsset: (req, res) => {
        const { asset_id, asset_details, model_no, serial_no, grcir_no,grcir_date,po_no,po_date, price,
            warrenty, vender, remark, peripherals, category_id, subcategory_id,
            asset_group_id, division_id,department_id,project_id,indent_no,indent_date, group, employee_id,
            acquired_date, issue_date, id } = req.body
        let asset = {
            category_id: category_id,
            subcategory_id: subcategory_id,
            asset_group_id: asset_group_id,
            division_id: division_id,
            department_id: department_id,
            project_id: project_id,
            employee_id: employee_id,
            acquired_date: acquired_date,
            issue_date: issue_date,
            indent_id: indent_no,
            indent_date: indent_date,
            group: group,
            asset_id: asset_id,
            asset_details: asset_details,
            model_no: model_no,
            serial_no: serial_no,
            grcir_no: grcir_no,
            grcir_date: grcir_date,
            po_no: po_no,
            po_date: po_date,
            price: price,
            warrenty: warrenty,
            vender: vender,
            remark: remark
        }
        Asset.update(asset, { where: { id: id } })
            .then(result => {
                res.status(200).json({ result: result })
            }).catch(err => {
                res.status(500).json({ result: err })
            })
        AssetPeripherals.destroy({ where: { asset_id: asset_id } })
        let len = peripherals.length;
        if (len) {
            for (let i = 0; i < len; i++) {
                let per = {
                    asset_id: asset_id,
                    peripherals_id: peripherals[i].peripherals_id,
                    serial_no: peripherals[i].serial_no
                }
                AssetPeripherals.create(per);
            }
        }
    },

    getNumber: (req, res) => {
        Asset.findAndCountAll({
            attributes: ["asset_id"],
            where: { asset_id: { [Op.like]: req.body.key + "%" } }
        }).then(result => {
            res.status(200).json({ result: result.count })
        }).catch(err => {
            res.status(500).json({ result: err })
        })
    }
}
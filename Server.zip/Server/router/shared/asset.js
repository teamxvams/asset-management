const router = require('express').Router();
const { getAllAsset, addAsset, updateAsset, getNumber } = require('../../controller/asset')

router.get('/getAll', getAllAsset);

router.post('/add', addAsset);

router.post('/update', updateAsset)

router.post('/getNumber', getNumber)

module.exports = router;
const {sequelize, DataTypes} = require('../config/db')

const Asset = sequelize.define('asset', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    category_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: "category",
            key: "id"
        }
    },
    subcategory_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: "subcategory",
            key: "id"
        }
    },
    asset_group_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: "asset_group",
            key: "id"
        }
    },
    division_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: "division",
            key: "id"
        }
    },
    department_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: "department",
            key: "id"
        }
    },
    project_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
            model: "project",
            key: "id"
        }
    },
    employee_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: "employee",
            key: "id"
        }
    },
    acquired_date: {
        type: DataTypes.DATE,
        allowNull: false
    },
    issue_date: {
        type: DataTypes.DATE,
        allowNull: false
    },
    indent_id: {
        type: DataTypes.STRING(50),
        allowNull: false
    },
    indent_date: {
        type: DataTypes.DATE,
        allowNull: false
    },
    asset_id: {
        type: DataTypes.STRING(30),
        allowNull: false
    },
    asset_details: {
        type: DataTypes.STRING(100),
        allowNull: false
    },
    model_no: {
        type: DataTypes.STRING(30)
    },
    serial_no: {
        type: DataTypes.STRING(30)
    },
    grcir_no: {
        type: DataTypes.STRING(30)
    },
    grcir_date: {
        type: DataTypes.DATE,
        allowNull: false
    },
    po_no: {
        type: DataTypes.STRING(30)
    },
    po_date: {
        type: DataTypes.DATE,
        allowNull: false
    },
    price: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    warrenty: {
        type: DataTypes.INTEGER
    },
    vender: {
        type: DataTypes.STRING(50)
    },
    remark: {
        type: DataTypes.STRING(150)
    }
},{
    timestamps: false,
    freezeTableName : true
})

module.exports = Asset
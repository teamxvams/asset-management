const router = require('express').Router()
const { Op } = require('sequelize')

const Employee = require('../model/employee')
const Status = require('../model/status')
const IndentDetails = require('../model/indent_details')
const AssetDetails = require('../model/asset')
const Department = require('../model/department')
const Project = require('../model/project')

router.post('/login', (req, res) => {
   
    const { username, password } = req.body
    

    Employee.findOne({
        attributes: ['id', 'emp_id', 'username', 'name', 'flag', 'department_id', 'designation_id'],
        where: {
            username: username,
            password: password
        }
    }).then(result => {
        if (result) res.status(200).send(result)
        else res.status(401).send("Unauthorized")
    }).catch(err => {
        res.status(500).send(err)
    })
})

router.post('/changePassword', (req, res) => {
    var { username, currentpass, newpass } = req.body
    Employee.findOne({
        attributes: ['id'],
        where: {
            username: username,
            password: currentpass
        }
    }).then(result => {
        if (result) {
            Employee.update(
                {
                    password: newpass,
                    flag: 1
                },
                { where: { id: result.id } }
            ).then(updated => {
                res.status(200).send(result)
            }).catch(err => {
                res.status(500).send(err)
            })
        }
        else res.status(401).send("Unauthorized")
    }).catch(err => {
        res.status(500).send(err)
    })
})

router.get('/getIndentInputs',(req,res)=>{
    department=0
    status=0
    project=0
    count=0
    Department.findAll().then(result=>{
        department=result;
        console.log(JSON.stringify(department));
    })
    
    Status.findAll().then(result=>{
        status=result;
        console.log(JSON.stringify(status));
    })
    IndentDetails.findAndCountAll().then(result=>{
        count=result.count
    })
    Project.findAll().then(result=>{
        project=result;
        res.status(200).json({department:department,status:status,project:project,count:count})
    }).catch(err => {
        res.status(500).json({ result: err })
    })
})

router.post('/addIndent', (req, res) => {
    console.log(req.body);
    const indent = req.body.indent
    console.log(JSON.stringify(indent))
            IndentDetails.bulkCreate(indent).then(data => {
                res.status(200).send(data);
            }).catch(err => {
                res.status(500).send(err);
            })
        })

router.post('/getIndentByEmployeeId', (req, res) => {
    console.log(req.body.employee_id);
    IndentDetails.findAll({
        where: { [Op.and]: [
            { "employee_id": req.body.employee_id },
            { "status_id":{[Op.lt]: 4}}
          ] }
    }).then(data => {
        res.status(200).json({ data: data });
    }).catch(err => {
        res.status(500).send(err);
    });
});

router.post('/getAssetByEmployeeID', (req, res) => {
    console.log(req.body.employee_id);
    AssetDetails.findAll({
        where: { "employee_id": req.body.employee_id }
          
    }).then(data => {
        res.status(200).json({ data: data });
    }).catch(err => {
        res.status(500).send(err);
    });
});

router.post('/submitIndent', (req, res) => {
    IndentDetails.update(
        { flag: 1 },
        { where: { "id": req.body.id } }
    ).then(data => {
        res.status(200).send(data);
    }).catch(err => {
        res.status(500).send(err);
    });
});

router.post('/deleteIndent', (req, res) => {
    IndentDetails.destroy(
        { where: { "id": req.body.id } }
    ).then(data => {
        res.status(200).send(data);
    }).catch(err => {
        res.status(500).send(err);
    });
});


router.get('/getStatus', isAuthorized, (req, res) => {
    Status.findAll().then((err, result) => {
        if (err)
            res.status(500).send(err);
        else
            res.status(200).send(result);
    })
})

function isAuthorized(req, res, next) {
    var id = req.headers.authorization;
    if (id) {
        Employee.findOne({
            where: {
                id: id
            }
        }).then(result => {
            if (result) next()
            else res.status(401).send("Unauthorized")
        })
    }
    else res.status(401).send("Unauthorized")
}

module.exports = router

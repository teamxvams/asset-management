const router = require('express').Router();
const { getPeripheralByAsset } = require('../../controller/asset_peripherals')


router.post('/getPeripheralByAsset', getPeripheralByAsset);

module.exports = router;
const router = require('express').Router();
const { getAllIndent , updateIndent} = require('../../controller/indent_details')

router.get('/getAll', getAllIndent);

router.post('/updateIndent', updateIndent);

module.exports = router;
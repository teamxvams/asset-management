const IndentDetails = require('../model/indent_details')
const { Op } = require('sequelize')

module.exports = {
    getAllIndent: (req, res) => {
        IndentDetails.findAll({
            attributes: ['id','indent_no','budget_year','project_id','employee_id','material_desc','quantity','price','manufacturer','suggested_vendors','remarks','status_id'],
            where:{ "status_id":{[Op.lt]: 4}}
        })
            .then(result => {
                res.status(200).json(result)
            })
            .catch(err => {
                res.status(500).json({ result: err })
            })
    },

    updateIndent:(req,res) =>{
        console.log(JSON.stringify(req.body))
        const item = req.body.item;
        IndentDetails.update(
            { material_desc: item.material_desc,price:item.price,quantity:item.quantity,manufacturer:item.manufacturer,suggested_vendors:item.suggested_vendors,remarks:item.remarks,status_id:item.status_id },
            { where: { "id": item.id } }
        ).then(data => {
            res.status(200).send(data);
        }).catch(err => {
            res.status(500).send(err);
        });
    }
}
module.exports = {
    username: "root",
    password: "pass12345",
    database: "asset_management",
    host: "localhost",
    dialect: "mysql",
}

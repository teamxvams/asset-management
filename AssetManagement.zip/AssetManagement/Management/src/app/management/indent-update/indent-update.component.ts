import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ManagementService } from 'src/app/service/management.service';
import { MatDialogRef } from '@angular/material';

@Component({
  selector: 'app-indent-update',
  templateUrl: './indent-update.component.html',
  styleUrls: ['./indent-update.component.scss']
})
export class IndentUpdateComponent implements OnInit {
  data:any  
  status = [
    { id:1,value:'Request forwarded'},
    { id:2,value:'Processing'},
    { id:3,value:'Out for Delivery'},
    { id:4,value:'Asset Acquired'}];

  constructor(private fb:FormBuilder,private ser:ManagementService, public dialogref: MatDialogRef<IndentUpdateComponent>) { }

  ngOnInit() {
    
    this.data=this.ser.getindentStatus();
    console.log(JSON.stringify(this.data))
    this.indent.patchValue({
      material_desc: this.data.material_desc,
      quantity:this.data.quantity,
      price:this.data.price,
      manufacturer:this.data.manufacturer,
      suggested_vendors: this.data.suggested_vendors,
      remarks: this.data.remarks,
      status_id:this.data.status_id
    });
  }

  indent:FormGroup=this.fb.group({ 
    
   material_desc:  ['', [Validators.required, Validators.maxLength(120)]],
   quantity:  ['',Validators.required],
   price:  [0,Validators.required],
   manufacturer:  [''],
   suggested_vendors:  [''],
   remarks:  [''],
   status_id:  [0]
 })

 afterUpdate(){
   this.data.material_desc=this.indent.get("material_desc").value;
   this.data.quantity=this.indent.get("quantity").value;
   this.data.price=this.indent.get("price").value;
   this.data.manufacturer=this.indent.get("manufacturer").value;
   this.data.suggested_vendors=this.indent.get("suggested_vendors").value;
   this.data.remarks=this.indent.get("remarks").value;
   this.data.status_id=this.indent.get("status_id").value;
   console.log(this.data);
   this.ser.updateIndentDetails(this.data).subscribe(res=>{
   this.ser.setIndentStatus(this.data);
   this.dialogref.close();
 });
 }

}

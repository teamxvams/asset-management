import { Indent } from './indent';

describe('Indent', () => {
  it('should create an instance', () => {
    expect(new Indent()).toBeTruthy();
  });
});

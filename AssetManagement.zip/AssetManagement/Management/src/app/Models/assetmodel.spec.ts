import { Assetmodel } from './assetmodel';

describe('Assetmodel', () => {
  it('should create an instance', () => {
    expect(new Assetmodel()).toBeTruthy();
  });
});

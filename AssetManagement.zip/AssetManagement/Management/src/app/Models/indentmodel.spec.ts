import { Indentmodel } from './indentmodel';

describe('Indentmodel', () => {
  it('should create an instance', () => {
    expect(new Indentmodel()).toBeTruthy();
  });
});

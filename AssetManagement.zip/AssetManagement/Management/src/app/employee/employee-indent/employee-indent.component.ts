import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { EmployeeService } from 'src/app/service/employee.service';
import { DepartmentService } from 'src/app/service/department.service';
import { StatusService } from 'src/app/service/status.service';
import { DataService } from 'src/app/service/data.service';
import { MatDialog, MatTableDataSource, MatDialogConfig } from '@angular/material';
import { EmployeesService } from 'src/app/shared/employees.service';
import { NotifiersService } from 'src/app/shared/notifiers.service';
import { Indentmodel } from 'src/app/Models/indentmodel';
import { PrintLayoutComponent } from '../print-layout/print-layout.component';

@Component({
  selector: 'app-employee-indent',
  templateUrl: './employee-indent.component.html',
  styleUrls: ['./employee-indent.component.scss']
})
export class EmployeeIndentComponent implements OnInit {

  constructor(private _employeeService:EmployeeService,private fb:FormBuilder,private notify:NotifiersService,public dialog: MatDialog, private service: EmployeesService) { }

  showSubmit:boolean=false;
  showTable:boolean=false;
  showAdd:boolean=false;
  showAfterUpdate:boolean=false;
  showdelete:boolean=false;
  count:number;
  updateRow:number;
  
  departments :any;
    project :any;
  key:number=0;
  modelArr=[];                      //model to be sent
  modelArr1:Indentmodel[]=[];                     //model for updation
  indentlist : MatTableDataSource<any>;
  displayColumns : string[] = ["srno","desc","manufacturer","qty","price","delivery","remark","sugvend","actions"];
  employee:any
  minDate=new Date();
  budget=[];
  status:any;

  ngOnInit() {
    this.employee=this._employeeService.currentEmployeeValue;
    this._employeeService.indentInputs().subscribe(data=>{
      this.project=data.project;
      this.departments=data.department;
      this.status=data.status;
      this.count=data.count;
  })
    for (let index = 0; index < 3; index++) {
      this.budget.push({id:index,value:(this.minDate.getFullYear()+(index-1))});
    }
  }

  

  /* indent= new FormGroup({
    $key: new FormControl(null),
    dept: new FormControl(''),
    date: new FormControl(''),
    budget: new FormControl('', Validators.required),
    project: new FormControl(''),
    srno: new FormControl(''),
    desc: new FormControl(''),
    manufacturer: new FormControl(''),
    qty: new FormControl(''),
    price: new FormControl(''),
    delivery: new FormControl(''),
    remark: new FormControl(''),
    sugvend: new FormControl(''),
  }); */
  indent:FormGroup=this.fb.group({
     $key: [0], 
    dept:  ['',Validators.required],
    date:  [this.minDate,Validators.required],
    budget: ['', Validators.required],
    project: ['',Validators.required],
    srno:  [1,Validators.required],
    desc:  ['', [Validators.required, Validators.maxLength(120)]],
    manufacturer:  [''],
    qty:  ['',Validators.required],
    price:  ['',Validators.required],
    delivery:  ['',Validators.required],
    remark:  [''],
    sugvend:  [''],
  })

  //indentArray=this.fb.array([]);
  
  
  addIndent(){
  
    /* if(this.indent.valid)
    {  */
      
    console.log(this.indent.value);
    //this.indentArray.push(<FormGroup>this.indent.value);
    //this.indentArray[0]=this.indent.value;
    //let d2=new DatePipe('en').transform(this.indent.get('delivery').value, 'MM/dd/yyyy');
    
    let q=this.indent.get('price').value;
    console.log(JSON.stringify(this.indent.get('date').value));
    
    //console.log(formatDate(this.indent.get('date').value, 'yyyy/mm/dd', 'en')); 
    
    this.modelArr.push(this.indent.value);
    
    
     
    //console.log(this.modelArr1);
    console.log(JSON.stringify(this.modelArr));
    
    console.log("---------")
    console.log(this.modelArr);
    //this.indent.reset();
    console.log(this.indent.get('$key'));
    this.key=this.key+1;
    this.initializeIndent();
    this.notify.successMsg('Added to the cart!!');
    this.indentlist=new MatTableDataSource(this.modelArr);
    this.showdelete=true;
    this.showTable=true;
    this.showSubmit=true;
    console.log(this.key);
   // }
  }

  

  initializeIndent() {
    this.indent.patchValue({
      $key:(this.key), 
      srno: (this.key+1),
      desc: ' ',
      qty: 0,
      price: 0,
      project: ' ',
      manufacturer: '',
      delivery: this.indent.get('delivery').value,
      remark: '',
      sugvend:''
    });
  }

  

  updateIndent(row:number){
    this.showdelete=false;
    this.showAdd=true;
    console.log(row);
    //this.indent=this.modelArr[0];
    /* this.indent.setValue(this.modelArr1[row]); */
     this.indent.patchValue({
      srno: this.modelArr[row].srno,
      desc: this.modelArr[row].desc,
      qty: this.modelArr[row].qty,
      price: this.modelArr[row].price,
      project: this.modelArr[row].project,
      manufacturer: this.modelArr[row].manufacturer,
      delivery: this.modelArr[row].delivery,
      remark: this.modelArr[row].remark,
      sugvend:this.modelArr[row].sugvend
    }); 
    this.updateRow=row;
    console.log(row);
    this.showAfterUpdate=true;
    
  }

  afterUpdate()
  {
    if(this.indent.valid){
      this.modelArr[this.updateRow]=this.indent.value;
      this.showAfterUpdate=false;
      this.indentlist=new MatTableDataSource(this.modelArr);
      this.initializeIndent();
      this.showAdd=false;
      this.showdelete=true;
    }
    
  }

  deleteIndent(row)
  {
    if(this.showdelete)
    {
      this.modelArr.splice(row,1);
      if(this.modelArr.length!=0)
      {
        for(let i=0;i<this.modelArr.length;i++)
        {
          if(this.modelArr[i].srno!=i+1)
          {
            this.modelArr[i].srno=i+1;
          }
        }
        this.key=this.modelArr.length;
        this.initializeIndent();
        this.indentlist=new MatTableDataSource(this.modelArr);
      }
      else
      {
        this.showTable=false;
        this.showSubmit=false;
        this.key=0;
        this.initializeIndent();
      }
    }
    else
      this.notify.errorMsg("Update indent before trying to delete!!");
  }
  

  onSubmit()
  {

    let dept:any;
    let budg:any;
    this.departments.forEach(element => {
      if(element.id==this.modelArr[0].dept){
        dept=element.name
      }
    });
    this.budget.forEach(element => {
      if(element.id==this.modelArr[0].budget){
        budg=element.value
      }
    });
    let ind_no=dept+budg+this.count;   //changes needed
    let indentlst=[];
    this.modelArr.forEach(element => {
      indentlst.push(
        {
          indent_no:ind_no,
          budget_year: element.budget,
          project_id: element.project,
          material_desc: element.desc,
          manufacturer: element.manufacturer,
          quantity: element.qty,
          price: element.price,
          remarks: element.remark,
          suggested_vendors: element.sugvend,
          status_id:this.status[0].id,
          employee_id:this.employee.id
        }
      )
    });
    console.log(indentlst)
     this._employeeService.addIndent(indentlst).subscribe(result=>{
      this.notify.successMsg("Indent saved to your account!!")
     })
    



    const config = new MatDialogConfig();

    config.width = "90%";
    config.height="100%";
    console.log(JSON.stringify(this.modelArr));
    
    this.dialog.open(PrintLayoutComponent, config);
    this.service.reqIndent(this.modelArr);



    this.key=0;
    this.initializeIndent();
    this.modelArr.splice(0)
    this.indentlist=new MatTableDataSource(this.modelArr);
    this.showTable=false;
  }
  

  /* onSubmit() {
    this.submitted = true
    // if (this.indentForm.invalid) return
    var date = new Date()
    var year = date.getFullYear()
    this.isLoading = true
    var indent_no = this.department_name + '/' + year
    var indent = {
      indent_no: indent_no,
      budget_year: this.budgetYear,
      project_id: 1,//this.indentForm.value.project_name,
      employee_id: this.emp.id,
      material_desc: this.indentForm.value.material_desc,
      quantity: this.indentForm.value.quantity,
      price: this.indentForm.value.price,
      manufacturer: this.indentForm.value.manufacturer,
      suggested_vendors: this.indentForm.value.suggested_vendors,
      remarks: this.indentForm.value.remarks,
      status_id: 1,
    }
    this._employeeService.addIndent(indent)
      .subscribe(data => {
        this._router.navigate(['/employee/home'])
      }, err => {
        this.isLoading = false
      })
  } */

}

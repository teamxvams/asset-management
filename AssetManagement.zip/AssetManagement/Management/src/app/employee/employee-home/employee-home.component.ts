import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { EmployeeService } from 'src/app/service/employee.service';
import { Router } from '@angular/router';
import { DepartmentService } from 'src/app/service/department.service';
import { StatusService } from 'src/app/service/status.service';
import { NotifierService } from 'angular-notifier';
import { DataService } from 'src/app/service/data.service';
import { Indentmodel } from 'src/app/Models/indentmodel';
import { MatTableDataSource, MatDialog, MatDialogConfig } from '@angular/material';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NotifiersService } from 'src/app/shared/notifiers.service';
import { EmployeesService } from 'src/app/shared/employees.service';
import { IndentStatusComponent } from '../indent-status/indent-status.component';

@Component({
  selector: 'app-employee-home',
  templateUrl: './employee-home.component.html',
  styleUrls: ['./employee-home.component.scss']
})
export class EmployeeHomeComponent implements OnInit {

  indentPending = []
  indentSubmitted = []
  indents: any = []
  departments: any = []
  status: any = []

  isLoading: boolean = false

  

  private _notifier: NotifierService
  /*
  constructor(
    private _titleService: Title,
    private _router: Router,
    private _employeeService: EmployeeService,
    private _departmentService: DepartmentService,
    private _statusService: StatusService,
    private _dataService: DataService,
    private notifier: NotifierService,
    private fb: FormBuilder,
    private notify: NotifiersService,
    private service: EmployeesService
  ) {
    this._titleService.setTitle('Employee Home')
    this._departmentService.setDepartment().then(data => this.departments = data)
    this._statusService.setStatus().then(data => this.status = data)
    this.emp = this._employeeService.currentEmployeeValue
    this._notifier = this.notifier
    if (!this._employeeService.currentEmployeeValue.flag) this._router.navigate(['/employee/changepassword'])
  }

  ngOnInit() {
    this.init()
  }

  init() {
    this.isLoading = true

    new Promise((res, rej) => {
      this._employeeService.getIndentByEmployeeId(this.emp.id)
        .subscribe(data => {
          this.indents = Object.assign([], data)
          res(this.indents)
        }, err => {
          this._notifier.notify('error', "Data fetching problem. Try again..!!")
          res(this.indents)
        })
    }).then((indentList: any[]) => {
      this.indentSubmitted = []
      this.indentPending = []
      indentList.forEach(async (indent) => {
        await this.status.forEach(s => {
          if (s.id == indent.status_id) indent["status_name"] = s.name
        })
        if (indent.flag) this.indentSubmitted.push(indent)
        else this.indentPending.push(indent)
      })
      this.isLoading = false
    })
    this.status = this._statusService.getStatus()
  }


  onEdit(item) {
    console.log(item)
    this._dataService.changeData(item)
    this._router.navigate(['/employee/indent'])
  }

  onSubmit(item) {
    this._employeeService.submitIndent({ id: item.id })
      .subscribe(data => {
        this.init()
        setTimeout(() => {
          this._notifier.notify("success", "Indent submitted successfully")
        }, 800)
      }, err => {
        this._notifier.notify("error", "Indent not submitted. Try again..!!")
      })
  }

  onDelete(item) {
    this._employeeService.deleteIndent({ id: item.id })
      .subscribe(data => {
        this.init()
        setTimeout(() => {
          this._notifier.notify("success", "Indent deleted successfully")
        }, 800)
      }, err => {
        this._notifier.notify("error", "Indent not deleted. Try again..!!")
      })
  }



  maxItem = [5, 10, 25, 50, 100]
  p: number = 1
  items: number = 5

  onMaxItemChange(items) {
    this.items = items
  }

  key: string = 'purchase' //set default
  previousKey: string = ''
  reverse: boolean = false
  sort(key) {
    this.previousKey = this.key
    this.key = key
    if (this.previousKey === this.key)
      this.reverse = !this.reverse

  } */
  
  indentlist: MatTableDataSource<any>;
  displayColumns: string[] = ["srno", "pno", "desc", "action"]
  index = 1;
  constructor(public dialog: MatDialog, private service: EmployeesService,private empservice:EmployeeService) { }

  ngOnInit() {
    console.log(this.empservice.currentEmployeeValue);
    let employee_id=this.empservice.currentEmployeeValue.id;
    this.empservice.getIndentByEmployeeId(employee_id).subscribe(result=>{
        result.data.forEach(element => {
        this.indents.push(element);
      });
      this.indentlist = new MatTableDataSource(this.indents);
    });
    
  }

  statusIndent(row: number) {
    
    const config = new MatDialogConfig();
    
    config.width = "40%";
    this.dialog.open(IndentStatusComponent, config);
    this.service.indentStatus(this.indents[row]);
    /* dialogref.afterClosed().subscribe(result => {
      console.log('The dialog was closed'); 
     
    });*/
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-slack-loader',
  templateUrl: './slack-loader.component.html',
  styleUrls: ['./slack-loader.component.scss']
})
export class SlackLoaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Injectable } from '@angular/core';
import { Api } from './URL';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AssetService {

  constructor(
    private _http: HttpClient
  ) { }

  getAssetNo(key) {
    return this._http.post<any>(Api.BASE_URL + "/management" + Api.getAssetNo, { key: key })
  }

  addAsset(asset) {
    return this._http.post<any>(Api.BASE_URL+"/management"+Api.addAsset, asset)
  }

  updateAsset(asset) {
    return this._http.post<any>(Api.BASE_URL+"/management"+Api.updateAsset, asset)
  }

  getAllAsset() {
    return this._http.get<any>(Api.BASE_URL+"/management"+Api.getAllAsset)
  }

}

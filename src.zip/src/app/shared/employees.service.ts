import { Injectable } from '@angular/core';
import { Indentmodel } from '../Models/indentmodel';
import { BehaviorSubject } from 'rxjs';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Injectable({
  providedIn: 'root'
})
export class EmployeesService {

  private ind:any;
  private indlist=[];
  private subject = new BehaviorSubject<string>("0");
  getPdf = this.subject.asObservable();
  constructor() { }

  fom: FormGroup = new FormGroup({
    $key: new FormControl(null),
    fullName: new FormControl('', Validators.required ),
    email: new FormControl('', Validators.email),
    mobile: new FormControl('', [Validators.required, Validators.minLength(10)]),
    city: new FormControl(''),
    gender: new FormControl('0'),
    department: new FormControl(1),
    hireDate: new FormControl(''),
    isPermanent: new FormControl(false)
  });

  indent: FormGroup = new FormGroup({
    $key: new FormControl(null),
    dept: new FormControl(''),
    date: new FormControl(''),
    budget: new FormControl('', Validators.required),
    project: new FormControl(''),
    srno: new FormControl(''),
    desc: new FormControl(''),
    manufacturer: new FormControl(''),
    qty: new FormControl(''),
    price: new FormControl(''),
    delivery: new FormControl(''),
    remark: new FormControl(''),
    sugvend: new FormControl(''),
  });

  initializeFormGroup() {
    this.fom.setValue({
      $key: null,
      fullName: '',
      email: '',
      mobile: '',
      city: '',
      gender: '1',
      department: 0,
      hireDate: '',
      isPermanent: false
    });
  }

  indentStatus(obj:any){
    this.ind=obj;
  }

  getIndentStatus(){
    return this.ind;
  }

  reqIndent(list:any){
    list.forEach(element => {
      this.indlist.push(element);
    });
  }

  getReqIndent(){
    return this.indlist;
  }

 

  getPDF(number){
    alert(number);
    this.subject.next(number);
  }
}

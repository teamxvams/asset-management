import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IndentStatusComponent } from './indent-status.component';

describe('IndentStatusComponent', () => {
  let component: IndentStatusComponent;
  let fixture: ComponentFixture<IndentStatusComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IndentStatusComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IndentStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';
import { Indentmodel } from 'src/app/Models/indentmodel';
import { Router } from '@angular/router';
import { MatDialogRef } from '@angular/material';
import { EmployeesService } from 'src/app/shared/employees.service';

@Component({
  selector: 'app-indent-status',
  templateUrl: './indent-status.component.html',
  styleUrls: ['./indent-status.component.scss']
})
export class IndentStatusComponent implements OnInit {

  message = " World!!";
  item = [1, 2, 3, 4];
  indent: any;
  status1: string;
  status2: string;
  status3: string;
  status4: string;

  constructor(
    private router: Router,
    public dialogref: MatDialogRef<IndentStatusComponent>,
    public service: EmployeesService
    /* @Inject(MAT_DIALOG_DATA) public data : [] */
  ) { }

  ngOnInit() {
    this.indent = this.service.getIndentStatus();
    switch (this.indent.status_id) {
      case 4:
        this.status1 = "active";
        this.status2 = "active";
        this.status3 = "active";
        this.status4 = "active";
        break;
      case 3:
        this.status1 = "active";
        this.status2 = "active";
        this.status3 = "active";
        this.status4 = "next";
        break;
      case 2:
        this.status1 = "active";
        this.status2 = "active";
        this.status3 = "next";
        break;
      case 1:
        this.status1 = "active";
        this.status2 = "next";
    }
  }





  onNoClick() {
    this.dialogref.close();
  }
}

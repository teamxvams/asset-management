import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { EmployeeService } from 'src/app/service/employee.service';
import { EmployeesService } from 'src/app/shared/employees.service';
import html2canvas from 'html2canvas';
import * as jspdf from 'jspdf';

@Component({
  selector: 'app-print-layout',
  templateUrl: './print-layout.component.html',
  styleUrls: ['./print-layout.component.scss']
})
export class PrintLayoutComponent implements OnInit {

  ast=[];
  departments = [
    { id: 1,value:'Dep 1'},
    { id: 2,value:'Dep 2'},
    { id: 3,value:'Dep 3'},
    { id: 4,value:'Dep 4'}];

  constructor(public dialogref: MatDialogRef<PrintLayoutComponent>,private service:EmployeesService) { }

  ngOnInit() {
    /* this.ast.push({dept:"101",date:"10-01-2019",budget:"2019-2020",project:"asf",srno:1,desc:"asf",manufacturer:"asf",qty:2,price:501,delivery:"12-05-2021",remark:"asfsaffsaf",sugvend:"qwq"},
    {dept:"101",date:"10-01-2019",budget:"2019-2020",project:"asf",srno:2,desc:"asf2222",manufacturer:"asf2222",qty:22,price:50122,delivery:"12-05-2222",remark:"asfsaffsaf2222",sugvend:"qwq222"});
  */
    this.ast=this.service.getReqIndent();
  }

  noPrint(){
    this.dialogref.close();
  }

  printIndent(){
    var data=document.getElementById('println');
    console.log(data);
    html2canvas(data).then(canvas =>{

      var imgWidth=290;
      var pageWidth=180;
      var imgHeight=canvas.height*imgWidth/canvas.width;
      var heightLeft=imgHeight;

      const contentDataURL=canvas.toDataURL('image/jpeg',1.0)
      let pdf=new jspdf('l','mm','a4');
      var position=0;
      pdf.addImage(contentDataURL,'JPEG', 0, 0, 275, 180)
      
      pdf.save('indent.pdf');
      this.ast=[];
    })

    /* let restorepage=document.body.innerHTML;
    let printcontent=document.getElementById('println').innerHTML;
    document.body.innerHTML=printcontent;
    window.print();
    document.body.innerHTML=restorepage;
    this.dialogref.close(); */
  }

}

import { Component, OnInit, ViewChild } from '@angular/core';
import { Assetmodel } from 'src/app/Models/assetmodel';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { EmployeeService } from 'src/app/service/employee.service';

@Component({
  selector: 'app-employee-asset',
  templateUrl: './employee-asset.component.html',
  styleUrls: ['./employee-asset.component.scss']
})
export class EmployeeAssetComponent implements OnInit {


  am=new Assetmodel();
  ast=[];
    constructor(private _employeeService:EmployeeService) { }
  
    astvl : MatTableDataSource<any>;
    displayColumns : string[] = ["indentno","indentdate","assetid","assetdetails","modelno","serialno","grcirno","grcirdate","pcno","price","warranty","vendor"];
    @ViewChild(MatSort,{static:true}) sort:MatSort;
    @ViewChild(MatPaginator,{static:true}) paginator:MatPaginator;
    searchKey:string;
    ngOnInit() {
        let employee_id=this._employeeService.currentEmployeeValue.id;
        this._employeeService.getAssetByEmployeeID(employee_id).subscribe(result=>{
        result.data.forEach(element => {
        this.ast.push(element);
      });
      this.astvl = new MatTableDataSource(this.ast);
      this.astvl.sort=this.sort;
      this.astvl.paginator=this.paginator;  
    });
  }
  onSearchClear()
  {
    this.searchKey="";
    this.applyFilter();
  } 
    applyFilter()
    {
      this.astvl.filter=this.searchKey.trim().toLowerCase();
    }

}

/* import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { CategoryService } from 'src/app/service/category.service';
import { SubCategoryService } from 'src/app/service/subcategory.service';
import { AssetGroupService } from 'src/app/service/assetgroup.service';
import { PeripheralService } from 'src/app/service/peripheral.service';
import { EmployeeService } from 'src/app/service/employee.service';
import { DivisionService } from 'src/app/service/division.service';
import { AssetPeripheralService } from 'src/app/service/asset-peripheral.service';
import { DepartmentService } from 'src/app/service/department.service';
import { DesignationService } from 'src/app/service/designation.service';

@Component({
  selector: 'app-management-home',
  templateUrl: './management-home.component.html',
  styleUrls: ['./management-home.component.scss']
})
export class ManagementHomeComponent implements OnInit {

  isLoading: boolean = false
  constructor(
    private _title: Title,
    private _categoryService: CategoryService,
    private _subcategoryService: SubCategoryService,
    private _assetGroupService: AssetGroupService,
    private _divisionService: DivisionService,
    private _peripheralService: PeripheralService,
    private _departmentService: DepartmentService,
    private _designationService: DesignationService,
    private _employeeService: EmployeeService,
  ) { 
    this._title.setTitle('Home')
    this._categoryService.setCategories()
    this._subcategoryService.setSubCategories()
    this._assetGroupService.setAssetGroup()
    this._divisionService.setDivision()
    this._peripheralService.setPeripherals()
    this._departmentService.setDepartment()
    this._designationService.setDesignation()
    this._employeeService.setEmployee()
  }

  ngOnInit() {
  }

}
 */

import { Component, OnInit, ViewChild } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { AssetService } from 'src/app/service/asset.service';
import { EmployeeService } from 'src/app/service/employee.service';
import { DataService } from 'src/app/service/data.service';
import { Router } from '@angular/router';
import { AssetPeripheralService } from 'src/app/service/asset-peripheral.service';
import { PeripheralService } from 'src/app/service/peripheral.service';
import { ManagementService } from 'src/app/service/management.service';
import { ExportAsService, ExportAsConfig } from 'ngx-export-as';
import { MatDialog, MatDialogConfig, MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { IndentUpdateComponent } from '../indent-update/indent-update.component';
@Component({
  selector: 'app-management-home',
  templateUrl: './management-home.component.html',
  styleUrls: ['./management-home.component.scss']
})
export class ManagementHomeComponent implements OnInit {
  astvl : MatTableDataSource<any>;
  displayColumns : string[] = ["id","indent_no","budget_year","project_id","employee_id","material_desc","quantity","price","manufacturer","suggested_vendors","remarks","status_id","actions"];
  @ViewChild(MatSort,{static:true}) sort:MatSort;
  @ViewChild(MatPaginator,{static:true}) paginator:MatPaginator;
  searchKey:string;
  
  assets: any = [] 
  indentlist: any //using this as dummy array
  employees: any = []
  groups: any = []
  peripherals: any = []
  assetPeripherals: any = []

  year: Number = null
  employee: string = null
  group: string = null
  public QrCode: string = null
  

  listOfYears = []
  listOfEmployee = []
  listOfGroups = []

  isLoading: boolean = false
  yearPrint: boolean = false
  employeePrint: boolean = false
  groupPrint: boolean = false
  encData: string = null;
  id: string = null;
  Openhide : boolean = false;
  config: ExportAsConfig;
  loc:number;
  boo:boolean=false;

  constructor(
    private _title: Title,
    private _assetService: AssetService,
    private _employeeService: EmployeeService,
    private _managementService: ManagementService,
    private _peripheral: PeripheralService,
    private _assetPeripheralService: AssetPeripheralService,
    private _dataService: DataService,
    private _router: Router,
    private exportAsService: ExportAsService,
    public dialog: MatDialog
  ) { this._title.setTitle("Home") }


  ngOnInit() {
   /* this.indentlist.push({id:1,indent_no:1,budget_year:"01/08/1996",project_id:1,employee_id:1,material_desc:"asdas",quantity:1,price:2,manufacturer:"vishnu",suggested_vendors:"sadf",remarks:"saff",status_id:1},
   {id:2,indent_no:1,budget_year:"01/08/1997",project_id:1,employee_id:2,material_desc:"asdas",quantity:1,price:2,manufacturer:"Shivani",suggested_vendors:"sadf",remarks:"saff",status_id:2}); */
   this._managementService.getIndentDetails().subscribe(result => {
    this.indentlist = result;
    this.astvl=new MatTableDataSource(this.indentlist);
    this.astvl.sort=this.sort;
    this.astvl.paginator=this.paginator;
  })
  //this._managementService.subject.subscribe((temp)=>{this.indentlist[this.loc]=temp;console.log(JSON.stringify(this.indentlist));this.astvl=new MatTableDataSource(this.indentlist)});
  }

  onSearchClear()
  {
    this.searchKey="";
    this.applyFilter();
  } 
    applyFilter()
    {
      this.astvl.filter=this.searchKey.trim().toLowerCase();
    }

  editindent(index) {
    console.log(index);
    this.loc=index;
    const config = new MatDialogConfig();
    
    config.width = "40%";
    this._managementService.indentStatus(this.indentlist[index]);
    this.dialog.open(IndentUpdateComponent, config); 
  }
  
}

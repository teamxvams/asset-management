import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IndentUpdateComponent } from './indent-update.component';

describe('IndentUpdateComponent', () => {
  let component: IndentUpdateComponent;
  let fixture: ComponentFixture<IndentUpdateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IndentUpdateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IndentUpdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

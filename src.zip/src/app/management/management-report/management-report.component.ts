import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { AssetService } from 'src/app/service/asset.service';
import { EmployeeService } from 'src/app/service/employee.service';
import { DataService } from 'src/app/service/data.service';
import { Router } from '@angular/router';
import { AssetPeripheralService } from 'src/app/service/asset-peripheral.service';
import { PeripheralService } from 'src/app/service/peripheral.service';
import { ManagementService } from 'src/app/service/management.service';
import { ExportAsService, ExportAsConfig } from 'ngx-export-as';
@Component({
  selector: 'app-management-report',
  templateUrl: './management-report.component.html',
  styleUrls: ['./management-report.component.scss']
})
export class ManagementReportComponent implements OnInit {
  assets: any = []
  employees: any = []
  groups: any = []
  peripherals: any = []
  assetPeripherals: any = []

  year: Number = null
  employee: string = null
  group: string = null
  public QrCode: string = null
  

  listOfYears = []
  listOfEmployee = []
  listOfGroups = []

  isLoading: boolean = false
  yearPrint: boolean = false
  employeePrint: boolean = false
  groupPrint: boolean = false
  encData: string = null;
  id: string = null;
  Openhide : boolean = false;
  config: ExportAsConfig;

  constructor(
    private _title: Title,
    private _assetService: AssetService,
    private _employeeService: EmployeeService,
    private _managementService: ManagementService,
    private _peripheral: PeripheralService,
    private _assetPeripheralService: AssetPeripheralService,
    private _dataService: DataService,
    private _router: Router,
    private exportAsService: ExportAsService
  ) { this._title.setTitle("Report") }

  ngOnInit() {
    this.Init();
  }
  Init() {
    Promise.all([this._peripheral.setPeripherals(), this._employeeService.setEmployee()])
      .then(values => {
        this.peripherals = values[0]
        this.employees = values[1]
        this.groups = this._managementService.getGroups()
      })
    this._assetService.getAllAsset()
      .subscribe((data: any) => {
        data.result.forEach(item => {
          this.employees.forEach(emp => {
            if (item.employee_id == emp.id) {
              item["employee_name"] = emp.name
              this.assets.push(item)
            }
          })
        })
      }, err => {
      })
  }

  editAsset(asset) {
    this._dataService.changeData(asset)
    this._router.navigate(['/management/asset'])
  }

  maxItem = [5, 10, 25, 50, 100]
  p: number = 1
  items: number = 5

  onMaxItemChange(items) {
    this.items = items
  }

  key: string = 'id' //set default
  previousKey: string = ''
  reverse: boolean = false
  sort(key) {
    this.previousKey = this.key
    this.key = key
    if (this.previousKey === this.key)
      this.reverse = !this.reverse
  }

  genQrcode(a){
    this.Openhide = true
    this.id = a.asset_id;
    this.encData ="\nAsset ID: "+a.asset_id+
                  "\n\nEmp Name: "+a.employee_name+
                  "\nGRCIR No: "+a.grcir_no+
                  "\nPO No: "+a.po_no+
                  "\nProject: "+a.project_id+
                  "\nAsset Details: "+a.asset_details
    this.QrCode = this.encData;
  }

  exportAsConfig: ExportAsConfig = {
    type: 'png', 
    elementId: 'QRCode'
  }
  png() {
      this.exportAsService.save(this.exportAsConfig,this.id).subscribe(() => {
      });
        this.exportAsService.get(this.config).subscribe(content => {
          console.log(content);
        });
  }

  print(value) {
    this.listOfYears = []
    this.listOfEmployee = []
    this.listOfGroups = []

    this.yearPrint = (value == 'yearPrint') ? true : false
    this.employeePrint = (value == 'employeePrint') ? true : false
    this.groupPrint = (value == 'groupPrint') ? true : false
    new Promise((res, rej) => {
      if (this.yearPrint) {
        if (!this.year) rej("year")
        this.assets.forEach(asset => {
          if (asset.asset_id.includes('CDACB/' + this.year)) {
            this.listOfYears.push(asset)
          }
        })
      }
      if (this.employeePrint) {
        if (!this.employee) rej("employee")
        this.assetPeripherals = []
        this.assets.forEach(asset => {
          if (asset.employee_id == this.employee) {
            this.listOfEmployee.push(asset)
            this._assetPeripheralService.getPeripheralByAsset(asset.id)
            .subscribe(data=>{
              this.assetPeripherals = data.result
            },err=>{
              //notifier add 
            })
            alert(JSON.stringify(asset))
          }
        })
      }
      if (this.groupPrint) {
        if (!this.group) rej("group")
        this.assets.forEach(asset => {
          if (asset.group == this.group) {
            this.listOfGroups.push(asset)
          }
        })
      }
      res(true)
    }).then(() => {
      setTimeout(() => {
        window.print()
      }, 888)
    }).catch(err => {

    })
  }

}

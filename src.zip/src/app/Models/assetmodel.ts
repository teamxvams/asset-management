export class Assetmodel {

indentno:number;
indentdate:string;
assetid:string;
assetdetails:string;
modelno:number;
serialno:number;
grcirno:number;
grcirdate:string;
pcno:number;
price:number;
warranty:number;
vendor:string

}

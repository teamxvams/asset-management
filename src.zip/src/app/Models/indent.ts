export class Indent {
    indent_no:string;
    budget_year: string;
    project_id: number;
    material_desc: string;
    manufacturer: string;
    quantity: number;
    price: number;
    remarks: string;
    suggested_vendors: string;
    status_id:number;
    employee_id:number;
}

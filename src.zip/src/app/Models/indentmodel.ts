export class Indentmodel {

    $key:number; 
    dept: string;
    date: string;
    budget: string;
    project: number;
    srno: number;
    desc: string;
    manufacturer: string;
    qty: number;
    price: number;
    delivery: string;
    remark: string;
    sugvend: string;
    pno:string;
    stat:number;
    
}
